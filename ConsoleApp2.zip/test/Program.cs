﻿using System;
using System.Xml.Schema;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            double priceWithoutTaxes = 0;
            double priceWithTaxes = 0;

            string input = string.Empty;
            double price = 0;
            double total = 0;

            while (double.TryParse(input = Console.ReadLine(), out price))
            {
                priceWithoutTaxes += price;
                priceWithTaxes += price * 0.2;
            }

            if (input == "special")
            {
                total = (priceWithTaxes + priceWithoutTaxes) * 0.90;
            }
            else
            {
                total = priceWithTaxes + priceWithoutTaxes;
            }

            Console.WriteLine(total);
        }
    }
}
