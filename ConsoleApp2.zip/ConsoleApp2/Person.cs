﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public abstract class Person : IPerson
    {
        public string Name { get; private set; }
        public int Age { get; private set; }
        public Eyes Eyes { get; private set; }
        public Hair Hair { get; private set; }
        public Skin Skin{ get; private set; }
        protected Person(string name, int age, Eyes eyes, Hair hair, Skin skin)
        {
            Name = name;
            Age = age;
            Eyes = eyes;
            Hair = hair;
            Skin = skin;
        }
        public virtual void Eat()
        {
            throw new NotImplementedException();
        }

        public virtual void Sleep()
        {
            throw new NotImplementedException();
        }

        public int Calculate(int a, int b)
        {
            throw new NotImplementedException();
        }
    }
}
