﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Male : Person
    {
        public Male(string name, int age, Eyes eyes, Hair hair, Skin skin) : base(name, age, eyes, hair, skin) { }
    }
}
