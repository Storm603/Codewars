﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ConsoleApp2
{
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(IsPrime(int.Parse(Console.ReadLine())));
            

            return;
            HashSet<string> strings = new HashSet<string>();

            strings.Add("name");
            strings.Add("name1");
            strings.Add("name2");
            strings.Add("name3");
            strings.Add("name");
            strings.Add("name");
            strings.Add("name");
            strings.Add("name");
            strings.Add("name4");

            return;

            Runner run = new Runner();
            run.Run();

            //Dictionary<string, char> countries = new Dictionary<string, char>()
            //{
            //    {"sa", '£'},
            //    {"sada", '£'},
            //    {"dfsa", '¥'},
            //    {"sadfsa", '$'},
            //    {"sads", '$'},
            //    {"sadfs", '$'}
            //};

            //Dictionary<char, int> metCount = new Dictionary<char, int>();

            //foreach (KeyValuePair<string, char> pair in countries.OrderBy(x => x.Value))
            //{
            //    if (!metCount.ContainsKey(pair.Value))
            //    {
            //        metCount.Add(pair.Value, 0);
            //    }

            //    metCount[pair.Value]++;
            //}

            //foreach (var pairt in metCount)
            //{
            //    Console.WriteLine(pairt.Key + " " + pairt.Value);
            //}
        }

        public static bool IsPrime(int n)
        {
            if (n <= 2 || n % 2 == 0)
            {
                return n == 2;
            }

            for (int i = 3; i <= Math.Sqrt(n); i += 2)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;

            //int count = 0;

            //for (int i = 1; i <= n; i++)
            //{
            //    if (n % i == 0)
            //    {
            //        count++;
            //    }
            //}

            //return count == 2;

        }
}
