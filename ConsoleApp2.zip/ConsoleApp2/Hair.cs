﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Hair
    {
        public Hair(string hairType, string hairColor)
        {
            HairType = hairType;
            HairColor = hairColor;
        }
        public string HairType { get; private set; }
        public string HairColor { get; private set; }
    }
}
