﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2.Enums
{
    public enum eyes
    {    
        black = 0,
        red = 1
    }


}
