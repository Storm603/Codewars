﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Skin
    {
        public Skin(string skinColor, string skinType)
        {
            SkinColor = skinColor;
            SkinType = skinType;
        }
        public string SkinColor { get; private set; }
        public string SkinType { get; private set; }
    }
}
