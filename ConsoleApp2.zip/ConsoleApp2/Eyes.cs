﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Eyes
    {
        public Eyes(string eyeColor) 
        {
            EyeColor = eyeColor;
            
        }
        public string EyeColor { get; private set; }
        public int Count = 2;
    }
}
