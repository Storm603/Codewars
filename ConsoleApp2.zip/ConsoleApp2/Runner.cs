﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    public class Runner
    {
        public void Run()
        {

        }
    }
}
