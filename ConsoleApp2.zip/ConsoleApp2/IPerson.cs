﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2
{
    interface IPerson
    {
        void Eat();
        void Sleep();
        int Calculate(int a, int b);
    }
}
