﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;
using ConsoleApp2.Enums;

namespace ConsoleApp2
{
    public class PersonAppearanceRandomizer
    {
        private Random rnd = new Random();
        public string EyeColor;

        public void EyeRandomiser()
        {
            int num = rnd.Next(0, 1);

            eyes val = (eyes) num;

            EyeColor = val.ToString();
        }
    }
}
