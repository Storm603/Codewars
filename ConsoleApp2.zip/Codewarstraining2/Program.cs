﻿using System;
using System.Collections.Generic;

namespace Codewarstraining2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(string.Join(", ", sqInRect(5, 3)));
        }

        public static List<int> sqInRect(int lng, int wdth)
        {
            if (lng == wdth) return null;
            List<int> list = new List<int>();
            while (lng > 0 && wdth > 0)
            {
                int max = Math.Max(lng, wdth);
                int min = Math.Min(lng, wdth);
                list.Add(min);
                wdth = min;
                lng = max - min;
            }
            return list;
        }
    }
}
